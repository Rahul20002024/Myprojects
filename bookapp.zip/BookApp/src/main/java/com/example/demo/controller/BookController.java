package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repositories.BookRepositary;
import com.example.demo.customexception.Resourcenotfound;
import com.example.demo.model.Book;
@RestController
@RequestMapping("/book")
@CrossOrigin(origins="http://localhost:4200")
public class BookController {
 @Autowired
 private BookRepositary bookrepo;
 	@GetMapping("/getbooks")
 	
 	public List<Book> getbooks(){
 		return bookrepo.findAll();
 	}
 	@PostMapping("/addbook")
 	public Book addBook(@RequestBody Book book) {
 		return bookrepo.save(book);
 	}
 	
 	public Book createBook(@RequestParam String name,@RequestParam int price) {
		Book book=new Book();
		book.setName(name);
		book.setPrice(price);
 		return bookrepo.save(book);
 	}
 	@GetMapping("/getbook/{id}")
 	public Book getBook(@PathVariable long id) {
 		
 			return bookrepo.findById(id).orElseThrow(()->new Resourcenotfound("Resource not found with this id :"+id));
 	}
 	@PutMapping("/editbook/{id}")
 	public Book editBook(@PathVariable long id,@RequestBody Book bookdetails){
 		
 		Book book1= bookrepo.findById(id).orElseThrow(()->new Resourcenotfound("Resource not found with this id :"+id));
 		book1.setName(bookdetails.getName());
 		book1.setAuthor(bookdetails.getAuthor());
 		book1.setPrice(bookdetails.getPrice());
		return bookrepo.save(book1);
 	}
 	@DeleteMapping("/deletebook/{id}")
 	@ResponseStatus(value=HttpStatus.NO_CONTENT)
public String deletBook(@PathVariable long id){
 		
 		Book book1= bookrepo.findById(id).orElseThrow(()->new Resourcenotfound("Resource not found with this id :"+id));
 		bookrepo.delete(book1);
		return "Successfully deleted book with id "+id;
}
}
