#!/usr/bin/env bash
set -euo pipefail
LIB_DIR="{1:-../lib}"
mkdir -p "$LIB_DIR"
urls=(
  "https://repo1.maven.org/maven2/org/springframework/spring-core/5.3.39/spring-core-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-jcl/5.3.39/spring-jcl-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-beans/5.3.39/spring-beans-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-context/5.3.39/spring-context-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-aop/5.3.39/spring-aop-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-expression/5.3.39/spring-expression-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-tx/5.3.39/spring-tx-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-orm/5.3.39/spring-orm-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/springframework/spring-jdbc/5.3.39/spring-jdbc-5.3.39.jar"
  "https://repo1.maven.org/maven2/org/hibernate/hibernate-core/5.6.15.Final/hibernate-core-5.6.15.Final.jar"
  "https://repo1.maven.org/maven2/org/hibernate/common/hibernate-commons-annotations/5.1.2.Final/hibernate-commons-annotations-5.1.2.Final.jar"
  "https://repo1.maven.org/maven2/org/jboss/logging/jboss-logging/3.4.3.Final/jboss-logging-3.4.3.Final.jar"
  "https://repo1.maven.org/maven2/org/jboss/jandex/2.4.3.Final/jandex-2.4.3.Final.jar"
  "https://repo1.maven.org/maven2/org/antlr/antlr/2.7.7/antlr-2.7.7.jar"
  "https://repo1.maven.org/maven2/org/dom4j/dom4j/2.1.4/dom4j-2.1.4.jar"
  "https://repo1.maven.org/maven2/org/glassfish/jaxb/jaxb-runtime/2.3.8/jaxb-runtime-2.3.8.jar"
  "https://repo1.maven.org/maven2/org/glassfish/jaxb/txw2/2.3.8/txw2-2.3.8.jar"
  "https://repo1.maven.org/maven2/com/sun/istack/istack-commons-runtime/3.0.12/istack-commons-runtime-3.0.12.jar"
  "https://repo1.maven.org/maven2/com/sun/xml/fastinfoset/FastInfoset/1.2.16/FastInfoset-1.2.16.jar"
  "https://repo1.maven.org/maven2/org/javassist/javassist/3.29.2-GA/javassist-3.29.2-GA.jar"
  "https://repo1.maven.org/maven2/javax/persistence/javax.persistence-api/2.2/javax.persistence-api-2.2.jar"
  "https://repo1.maven.org/maven2/mysql/mysql-connector-java/8.0.33/mysql-connector-java-8.0.33.jar"
  "https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.36/slf4j-api-1.7.36.jar"
  "https://repo1.maven.org/maven2/ch/qos/logback/logback-classic/1.2.12/logback-classic-1.2.12.jar"
  "https://repo1.maven.org/maven2/ch/qos/logback/logback-core/1.2.12/logback-core-1.2.12.jar"
)
for u in "${urls[@]}"; do
  f="$(basename "$u")"
  if [ ! -f "$LIB_DIR/$f" ]; then
    echo "Downloading $f ..."
    curl -L "$u" -o "$LIB_DIR/$f"
  else
    echo "Already exists: $f"
  fi
done
echo "All jars downloaded to $LIB_DIR"
