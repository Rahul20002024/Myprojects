# EmployeeManagementSystem (Non-Maven) — Spring 5 + Hibernate 5 + MySQL

**Goal:** You only create the database (`emsdb`) in MySQL. Hibernate will auto-create/update the `employee` table.

## 1) Create Database (only DB)
```sql
CREATE DATABASE emsdb;
```

## 2) Configure MySQL credentials
If needed, edit `src/resources/applicationContext.xml` (username/password). Defaults:
- user: `root`
- password: `admin`

## 3) Download JARs (no Maven/Gradle)
Run one of these to populate the `lib/` folder:

### Windows PowerShell
```powershell
cd scripts
./get-libs.ps1
```

### Linux/Mac
```bash
cd scripts
chmod +x get-libs.sh
./get-libs.sh
```

## 4) Import into Eclipse
- File → Import → Existing Projects into Workspace → select project root
- Right-click project → Properties → Java Build Path → Libraries → Add External JARs… → add **all** JARs from `lib/`
- Ensure Java 11 or 17 runtime is selected (Spring 5/Hibernate 5 friendly).

## 5) Run
- Run `com.ems.controller.MainController` as a Java Application.
- Hibernate will create/update table `employee` in `emsdb` because `hibernate.hbm2ddl.auto=update`.

## Features
- Insert, Delete, List, Search Employee
- Fields: `id`, `name`, `contactNumber`, `place`

## Troubleshooting
- If `NoClassDefFoundError`, verify all jars in `lib/` are added to the build path.
- If `Communications link failure`, check MySQL is running and URL/credentials in `applicationContext.xml` are correct.
