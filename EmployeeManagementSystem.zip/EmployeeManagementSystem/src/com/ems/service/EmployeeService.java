package com.ems.service;

import com.ems.dao.EmployeeDAO;
import com.ems.entity.Employee;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeDAO employeeDAO;

    public EmployeeService(EmployeeDAO employeeDAO) {
        this.employeeDAO = employeeDAO;
    }

    @Transactional
    public void addEmployee(Employee employee) {
        employeeDAO.insertEmployee(employee);
    }

    @Transactional
    public void deleteEmployee(int id) {
        employeeDAO.deleteEmployee(id);
    }

    @Transactional(readOnly = true)
    public List<Employee> getAllEmployees() {
        return employeeDAO.listEmployees();
    }

    @Transactional(readOnly = true)
    public Employee findEmployee(int id) {
        return employeeDAO.searchEmployee(id);
    }
}
