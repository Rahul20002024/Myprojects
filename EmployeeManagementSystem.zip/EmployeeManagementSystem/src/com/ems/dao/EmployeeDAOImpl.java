package com.ems.dao;

import com.ems.entity.Employee;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

    private final SessionFactory sessionFactory;

    public EmployeeDAOImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session currentSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public void insertEmployee(Employee employee) {
        currentSession().persist(employee);
    }

    @Override
    public void deleteEmployee(int id) {
        Employee emp = currentSession().get(Employee.class, id);
        if (emp != null) {
            currentSession().remove(emp);
        }
    }

    @Override
    public List<Employee> listEmployees() {
        return currentSession().createQuery("from Employee", Employee.class).getResultList();
    }

    @Override
    public Employee searchEmployee(int id) {
        return currentSession().get(Employee.class, id);
    }
}
