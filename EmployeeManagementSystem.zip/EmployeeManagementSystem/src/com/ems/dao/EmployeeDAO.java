package com.ems.dao;

import com.ems.entity.Employee;
import java.util.List;

public interface EmployeeDAO {
    void insertEmployee(Employee employee);
    void deleteEmployee(int id);
    List<Employee> listEmployees();
    Employee searchEmployee(int id);
}
