package com.ems.controller;

import com.ems.entity.Employee;
import com.ems.service.EmployeeService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Scanner;

public class MainController {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeService service = ctx.getBean(EmployeeService.class);

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Employee Management System ===");
            System.out.println("1. Insert Employee");
            System.out.println("2. Delete Employee");
            System.out.println("3. List Employees");
            System.out.println("4. Search Employee");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int ch = Integer.parseInt(sc.nextLine().trim());

            try {
                switch (ch) {
                    case 1:
                        Employee e = new Employee();
                        System.out.print("Name: "); e.setName(sc.nextLine());
                        System.out.print("Contact Number: "); e.setContactNumber(sc.nextLine());
                        System.out.print("Place: "); e.setPlace(sc.nextLine());
                        service.addEmployee(e);
                        System.out.println("Inserted with ID: " + e.getId());
                        break;
                    case 2:
                        System.out.print("Enter ID to delete: ");
                        int delId = Integer.parseInt(sc.nextLine().trim());
                        service.deleteEmployee(delId);
                        System.out.println("Deleted if existed.");
                        break;
                    case 3:
                        List<Employee> list = service.getAllEmployees();
                        if (list.isEmpty()) System.out.println("No employees found.");
                        else list.forEach(emp -> System.out.println(
                                emp.getId() + " | " + emp.getName() + " | " + emp.getContactNumber() + " | " + emp.getPlace()));
                        break;
                    case 4:
                        System.out.print("Enter ID to search: ");
                        int sid = Integer.parseInt(sc.nextLine().trim());
                        Employee found = service.findEmployee(sid);
                        if (found == null) System.out.println("Not found.");
                        else System.out.println(found.getId() + " | " + found.getName() + " | " + found.getContactNumber() + " | " + found.getPlace());
                        break;
                    case 5:
                        System.out.println("Bye!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
