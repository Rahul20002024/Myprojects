# Movie-seat-project
Spring boot, Movie seat selection mechanism, Spring Data Jpa, Thymeleaf,

just clone the repo
$git clone url..

open in eclipse or intellij

Please update the repo and change Jpa configuration acording to your system before run
And enjoy repo

