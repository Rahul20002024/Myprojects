param(
    [string]$LibDir = "../lib"
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $LibDir | Out-Null

$urls = @(
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot/3.3.2/spring-boot-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-autoconfigure/3.3.2/spring-boot-autoconfigure-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter/3.3.2/spring-boot-starter-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-web/3.3.2/spring-boot-starter-web-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-json/3.3.2/spring-boot-starter-json-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-logging/3.3.2/spring-boot-starter-logging-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-data-jpa/3.3.2/spring-boot-starter-data-jpa-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-aop/6.1.10/spring-aop-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-beans/6.1.10/spring-beans-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-context/6.1.10/spring-context-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-core/6.1.10/spring-core-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-expression/6.1.10/spring-expression-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-jcl/6.1.10/spring-jcl-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-web/6.1.10/spring-web-6.1.10.jar"
    "https://repo1.maven.org/maven2/org/springframework/spring-webmvc/6.1.10/spring-webmvc-6.1.10.jar"
    "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-annotations/2.17.2/jackson-annotations-2.17.2.jar"
    "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-core/2.17.2/jackson-core-2.17.2.jar"
    "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-databind/2.17.2/jackson-databind-2.17.2.jar"
    "https://repo1.maven.org/maven2/com/fasterxml/jackson/datatype/jackson-datatype-jdk8/2.17.2/jackson-datatype-jdk8-2.17.2.jar"
    "https://repo1.maven.org/maven2/com/fasterxml/jackson/datatype/jackson-datatype-jsr310/2.17.2/jackson-datatype-jsr310-2.17.2.jar"
    "https://repo1.maven.org/maven2/com/fasterxml/jackson/module/jackson-module-parameter-names/2.17.2/jackson-module-parameter-names-2.17.2.jar"
    "https://repo1.maven.org/maven2/org/hibernate/orm/hibernate-core/6.5.2.Final/hibernate-core-6.5.2.Final.jar"
    "https://repo1.maven.org/maven2/org/hibernate/common/hibernate-commons-annotations/6.0.7.Final/hibernate-commons-annotations-6.0.7.Final.jar"
    "https://repo1.maven.org/maven2/com/zaxxer/HikariCP/5.1.0/HikariCP-5.1.0.jar"
    "https://repo1.maven.org/maven2/org/springframework/data/spring-data-jpa/3.3.2/spring-data-jpa-3.3.2.jar"
    "https://repo1.maven.org/maven2/org/springframework/data/spring-data-commons/3.3.2/spring-data-commons-3.3.2.jar"
    "https://repo1.maven.org/maven2/jakarta/persistence/jakarta.persistence-api/3.1.0/jakarta.persistence-api-3.1.0.jar"
    "https://repo1.maven.org/maven2/jakarta/transaction/jakarta.transaction-api/2.0.1/jakarta.transaction-api-2.0.1.jar"
    "https://repo1.maven.org/maven2/jakarta/annotation/jakarta.annotation-api/2.1.1/jakarta.annotation-api-2.1.1.jar"
    "https://repo1.maven.org/maven2/com/h2database/h2/2.2.224/h2-2.2.224.jar"
    "https://repo1.maven.org/maven2/org/slf4j/slf4j-api/2.0.12/slf4j-api-2.0.12.jar"
    "https://repo1.maven.org/maven2/ch/qos/logback/logback-classic/1.5.6/logback-classic-1.5.6.jar"
    "https://repo1.maven.org/maven2/ch/qos/logback/logback-core/1.5.6/logback-core-1.5.6.jar"
    "https://repo1.maven.org/maven2/org/slf4j/jul-to-slf4j/2.0.12/jul-to-slf4j-2.0.12.jar"
    "https://repo1.maven.org/maven2/org/slf4j/log4j-over-slf4j/2.0.12/log4j-over-slf4j-2.0.12.jar"
    "https://repo1.maven.org/maven2/org/jboss/logging/jboss-logging/3.5.3.Final/jboss-logging-3.5.3.Final.jar"
    "https://repo1.maven.org/maven2/net/bytebuddy/byte-buddy/1.14.17/byte-buddy-1.14.17.jar"
    "https://repo1.maven.org/maven2/org/glassfish/jakarta.json/2.0.1/jakarta.json-2.0.1.jar"
)

foreach ($u in $urls) { 
  $fname = Split-Path $u -Leaf
  $dest = Join-Path $LibDir $fname
  if (-Not (Test-Path $dest)) {
    Write-Host "Downloading $fname ..."
    Invoke-WebRequest -Uri $u -OutFile $dest
  } else {
    Write-Host "Already exists: $fname"
  }
}
Write-Host "All jars downloaded to $LibDir"
